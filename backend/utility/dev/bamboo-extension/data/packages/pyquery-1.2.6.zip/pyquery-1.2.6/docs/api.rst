================================================
:mod:`~pyquery.pyquery` -- PyQuery complete API
================================================

.. automodule:: pyquery.pyquery

.. autoclass:: PyQuery
   :members:


